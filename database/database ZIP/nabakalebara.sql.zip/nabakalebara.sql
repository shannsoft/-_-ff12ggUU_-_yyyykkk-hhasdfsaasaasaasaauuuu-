-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 01, 2015 at 02:56 PM
-- Server version: 5.1.41
-- PHP Version: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `nabakalebara`
--

-- --------------------------------------------------------

--
-- Table structure for table `about`
--

CREATE TABLE IF NOT EXISTS `about` (
  `AboutID` int(11) NOT NULL,
  `AboutName` varchar(500) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `about`
--

INSERT INTO `about` (`AboutID`, `AboutName`) VALUES
(1, 'About Nabkalebara ');

-- --------------------------------------------------------

--
-- Table structure for table `bus`
--

CREATE TABLE IF NOT EXISTS `bus` (
  `BusID` int(11) NOT NULL AUTO_INCREMENT,
  `BusNumber` int(11) NOT NULL,
  `BusName` varchar(100) NOT NULL,
  `FromStation` varchar(100) NOT NULL,
  `ToStation` varchar(100) NOT NULL,
  `StartsAt` time NOT NULL,
  `ReachesAt` time NOT NULL,
  `CityId` int(11) NOT NULL,
  PRIMARY KEY (`BusID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `bus`
--


-- --------------------------------------------------------

--
-- Table structure for table `city`
--

CREATE TABLE IF NOT EXISTS `city` (
  `CityID` int(11) NOT NULL AUTO_INCREMENT,
  `CityName` varchar(50) NOT NULL,
  `StateID` int(11) NOT NULL,
  `CountryID` int(11) NOT NULL,
  `STDCode` int(11) NOT NULL,
  PRIMARY KEY (`CityID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `city`
--

INSERT INTO `city` (`CityID`, `CityName`, `StateID`, `CountryID`, `STDCode`) VALUES
(1, 'puri', 1, 1, 6752);

-- --------------------------------------------------------

--
-- Table structure for table `country`
--

CREATE TABLE IF NOT EXISTS `country` (
  `ContryID` int(11) NOT NULL AUTO_INCREMENT,
  `CountryName` varchar(50) NOT NULL,
  `ISDCode` int(11) NOT NULL,
  `Currency` varchar(50) NOT NULL,
  PRIMARY KEY (`ContryID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `country`
--

INSERT INTO `country` (`ContryID`, `CountryName`, `ISDCode`, `Currency`) VALUES
(1, 'india', 91, 'INR');

-- --------------------------------------------------------

--
-- Table structure for table `hotels`
--

CREATE TABLE IF NOT EXISTS `hotels` (
  `HotelID` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) NOT NULL,
  `Address` varchar(500) NOT NULL,
  `Phone` varchar(20) NOT NULL,
  `Phone2` varchar(20) NOT NULL,
  `Phone3` varchar(20) NOT NULL,
  `Fax` varchar(50) NOT NULL,
  `Mobile` varchar(20) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Website` varchar(50) NOT NULL,
  `Category` varchar(50) NOT NULL,
  `NoOfRooms` varchar(255) NOT NULL,
  `Facilities` varchar(500) NOT NULL,
  `CityId` int(11) NOT NULL,
  PRIMARY KEY (`HotelID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

--
-- Dumping data for table `hotels`
--

INSERT INTO `hotels` (`HotelID`, `Name`, `Address`, `Phone`, `Phone2`, `Phone3`, `Fax`, `Mobile`, `Email`, `Website`, `Category`, `NoOfRooms`, `Facilities`, `CityId`) VALUES
(1, 'Hotel Toshali Sands', 'Puri Konark Marine Drive, Puri-2 ', '250572', '250571', '250573', '250899', '0', 'tosalisands@tosalian', 'www.toshalisands.com', '4 Star', '108/216 Deluxe Room:43 Cottage:          42 Executive Dlx:10 Villa:              9 Executive Villa-4 Extra Bed', 'R,B,SP,CH,CC,TT,PS,DC,LIB,IG,Pvt. Beach Yoga,Spa,MC.', 1),
(2, 'Hotel May Fair Beach Resort', 'C. T. Road, Puri ', '227800', '0', '0', '224242', '0', 'puri@mayfairhotels.com', 'www.mayfairhotels.com/mayfair-puri/', '3 Star', '34/68 D/R:9(A/C) Cottage :21(A/C) Suite: 4', 'R,B,SP,CH,TT,G,CC, CTV,Spa', 1),
(3, 'Hotel Hans Coco Palms', 'Baliapanda, Puri ', '230038', '230951', '230952', '230165', '0', 'Hanscocopalms@hanshotels.com', 'www.hanshotels.com/puri/', '3 Star', '37/74 D/R :36(A/C) Suite-1 Extra bed', 'R,B,SP,CH,CTV, TT, LIB., MC, CC, Wi Fi, LS,DC,CS', 1),
(4, 'Hotel Shakti International', 'VIP Road, Puri-752001', '222388', '222488', '0', '228784', '0', 'shakti_int@yahoo.co.in', 'www.shaktiinternational.in', '3 Star', '36/72 D/R:34(A/C) D/R:2(A/C) Extra Bed', 'R,CH,CC,TT,DC, H&C,LS,SP', 1),
(5, 'Hotel Ananya Resorts', 'Bankimuhan,VIP Road, Puri', '220031', '220032', '0', '0', '0', 'ananya.resorts@gmail.com', 'www.ananyaresorts.in', 'HSG', '52/104 Dlx:40 Super Dlx:10 Suit:2 Ext Person', 'R ,SP ,TT,BAR,DC, LS,PP,p', 1),
(6, ' Hotel Anjana Resort', 'Gopal Ballav Road, Puri', '222117', '0', '0', '0', '0', '', 'www.hotelcontactnumber.in/anjana-hotel-hotel-9675.', 'HSG', '27/64 D/R-9 D/R-8(A/C) T/R-9 F/R-1', 'R,TT,CTV', 1),
(7, 'Hotel Arya Palace', 'C.T.Road, Puri', '232688', '232689', '0', '0', '0', '', 'www.aryagroupofhotels.com/', 'HSG', '30/67 Suite:4(A/C)  D/R:13(A/C) D/R:10(N.A/C) T/R: 2 T/R:1(A/C)', 'TV,LS, DC, TT, R,DC, PP,Baby Food.', 1),
(8, 'Hotel Ashray', 'Infront of Sankaracharya Matha, Goudabad Sahi,Puri.', '231742', '254142', '0', '254142', '0', '', 'www.hotelashray.in', 'HSG', '32/80 F/R-1(A/C) F/R:2 D/R-12 D/R:7  (A/C) T/R-4(A/C) T/R:6', 'R,SS,PP,TV, LS, DC, H&C', 1),
(9, 'Hotel Asian Inn', 'New Marine Drive Road, Puri', '231307', '231347', '0', '231348', '0', '', 'www.hotelasianinn.in', 'HSG', '30/60  D/R:24(A/C)  D/R.-6(A/C)', 'R,Tel,H&C,MC,TT,LS,DC,CR,SS,ART, CTV,Lift,Locker', 1),
(10, 'Hotel Banga Laxmi', 'New Marine Drive Road,  Swargadwar,Puri', '230711', '231811', '0', '0', '0', '', 'hotelbangalaxmi.com', 'HSG', '56/114 F/R:1(A/C) D/R:6(A/C) D/R:18(A/C) D/R:21(NA/C) D/R:10(N.A/C)', 'R,Bar, PP,Tel,H&C, TT,LS,DC,CR,SS,ARTCTV,Lift,Locker,CR, TD,CH,Ayurvedi Massage', 1),
(11, 'Hotel Basil Rock', 'Chaktratirtha Road,Puri', '233240', '233250', '0', '0', '0', '', 'www.tripadvisor.in/Basil_Hotel', 'HSG', '32/64 D/R:32(A/C) Non A/C', 'R ,PP,DC,CTV,DC,TT  SS,LS,ATM in the Campus', 1),
(12, 'Blue Lily Beach Resort', 'Sipasarubali,Baliapanda Puri-752001,Odisha', '230371', '230372', '0', '0', '9583003751', 'reservation@bluelilybeachresort.com ', 'www.bluelilybeachresort.com', 'HSG', '121/242 Primium D/R:30(A/C) D/R:90(A/C) Suit:1(A/C) Extra Pax', 'R,SP,CH,Bar,SPA, Lawn,Gym, Coffee shop,CTV,Tel, H&C,LS,DC,TT', 1),
(13, 'Hotel Bideshi Ghar ', 'Swargadwar, Puri', '223143', '225161', '0', '0', '0', '', 'www.bideshghar.com/', 'HSG', '30/60 D/R-11(A/C) D/R-19', 'R,LS,DC,SS', 1),
(14, 'Hotel Camellia', 'New Marine Drive Road,puri', '231424', '254131', '231084', '0', '0', 'camellia.resorts@gmail.com', 'www.cameliagroup.org', 'HSG', '39/84 Suite2(A/C)  D/R- 10(A/C) D/R- 24(A/C) F/R:3(A/C)', 'TV, LS, DC, TT, R, SP,CH, IG,  Free transport to  Rly. Station.', 1),
(15, ' Hotel Chanakya ', 'B.N.R.  C. T. Road, Puri-2 ', '223006', '0', '0', '222063', '0', 'therail@gmail.com ', 'www.therail.com', 'HSG', '37/74 D/R -37 (A/C)', 'R,  PP,CTV, TT DC,  H&C,LS', 1),
(16, 'Hotel The Chariot', 'Sipasurabali, Puri-752001', '231900', '0', '0', '231912', '0', 'brijsons08yahoo.com', 'www.thechariotpuri.com', 'HSG', '137/274 Platinum Suite:15 Deluxe Suit:20 Excucative D/R :38 Premium D/R :30 Deluxe D/R :34', 'R,SP,CC ,HC, TT,DC,CTV,PP, TD,CC,LS, Gm&Health Club', 1),
(17, 'Dalmia Atithi Vihar', 'C.T. Road, Puri-2', '225557', '226861', '0', '222694', '0', 'dalmiavihar@sancharnet.in', '', 'HSG', '23/48 Suite-2  D/R-11(A/C) D/R-9(A/C)  F/R-1(A/C)', 'R(Veg),PP, CTV, TT, DC, H&C,LS Recreation Hall Check Out: 24 hours', 1),
(18, 'Hotel Deep Resort', 'Sea-Beach, Puri', '220848', '0', '0', '0', '0', '', 'www.deepresorts.com/', 'HSG', '47/126 D/R-30(A/C) D/R-Dlx(A/C)Suit T/R-2(A/C) F/R-15(A/C) F/R-N A/C', 'R,TV, LS,TT', 1),
(19, ' Hotel Deepak', 'CT Road, Puri', '222370', '321909', '0', '0', '0', 'reservation@deeepak.com, ddgsons@gmail.com', 'www.deepak.com', 'HSG', '20/40 D/R:16 (A/C) D/R:4 (N.A/C)', 'LS,Tel,CTV,TT,CR,PP ', 1),
(20, ' Hotel Dolphin', 'Swargadwar Road, Puri', '231453', '0', '0', '0', '9938872137', '', 'www.hoteldolphin.in/', 'HSG', '28/56 D/R:23(A/C) D/R:5(N.A/C) Extra Person ', 'CTV,R,DC,TT, Roof top Garden,CR', 1);

-- --------------------------------------------------------

--
-- Table structure for table `hotel_rooms`
--

CREATE TABLE IF NOT EXISTS `hotel_rooms` (
  `HotelRoomID` int(11) NOT NULL AUTO_INCREMENT,
  `HotellID` int(11) NOT NULL,
  `Type` varchar(100) NOT NULL,
  `NoOfRooms` int(11) NOT NULL,
  `PriceStarts` int(11) NOT NULL,
  `PriceEnds` int(11) NOT NULL,
  PRIMARY KEY (`HotelRoomID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `hotel_rooms`
--


-- --------------------------------------------------------

--
-- Table structure for table `state`
--

CREATE TABLE IF NOT EXISTS `state` (
  `StateID` int(11) NOT NULL AUTO_INCREMENT,
  `StateName` varchar(50) NOT NULL,
  `CountryID` int(11) NOT NULL,
  PRIMARY KEY (`StateID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `state`
--

INSERT INTO `state` (`StateID`, `StateName`, `CountryID`) VALUES
(1, 'odisha', 1);

-- --------------------------------------------------------

--
-- Table structure for table `train`
--

CREATE TABLE IF NOT EXISTS `train` (
  `TrainID` int(11) NOT NULL AUTO_INCREMENT,
  `TrainNumber` int(11) NOT NULL,
  `TrainName` varchar(100) NOT NULL,
  `FromStation` varchar(100) NOT NULL,
  `ToStation` varchar(100) NOT NULL,
  `StartAt` time NOT NULL,
  `ReachesAt` time NOT NULL,
  `Monday` tinyint(4) NOT NULL,
  `Tuesday` tinyint(4) NOT NULL,
  `Wednesday` tinyint(4) NOT NULL,
  `Thursday` tinyint(4) NOT NULL,
  `Friday` tinyint(4) NOT NULL,
  `Saturday` tinyint(4) NOT NULL,
  `Sunday` tinyint(4) NOT NULL,
  `CityID` int(11) NOT NULL,
  PRIMARY KEY (`TrainID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `train`
--


/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
